#!/bin/bash

# merge videos with chapters
# caution: does NOT overwrite in_frames.mp4
sudo ./chapter.sh merge_as_chapter ./$1/*.mp4 ./$1/in_frames.mp4

# apply frame counter to in_frames.mp4
# result is saved as out_frames.mp4
# caution: overwrites out_frames.mp4
ffmpeg -i ./$1/in_frames.mp4 -vf "drawtext='fontfile=C\:/Windows/fonts/consola.ttf:fontsize=60: text=|Frame %{eif\:n\:d\:3}|: x=(w-tw)/2: y=h-(2*lh): fontcolor=white: box=1: boxcolor=0x00000099'" -y -c:a copy ./$1/out_frames.mp4